var mesg={
          tip:function(msg){
          	    layer.open({
			       content:msg,
			       style: 'background-color:#fff; color:#333; border:none;',
			       time:2,
			});
          },
          bgn:function(){
          	   layer.open({type: 2,});
          },
          close:function(){
          	  
          },
         

}